<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla view library
jimport('joomla.application.component.view');
 
/**
 * HTML View class for the HelloWorld Component
 */
class TimeTrackerViewTimeTracker extends JView
{
        // Overwriting JView display method
        function display($tpl = null) 
        {
                // Assign data to the view
                $this->msg = $this->get('Profile');
                $this->hours = $this->makeTimeDropdown();
                $this->weekendings = $this->makeWeekEndingDropdown();
                $this->weekdays = $this->makeWeekDaysDropdown();
                $this->spentHours = $this->makeSpendTimeDropdown();
 
                // Check for errors.
                if (count($errors = $this->get('Errors'))) 
                {
                        JLog::add(implode('<br />', $errors), JLog::WARNING, 'jerror');
                        return false;
                }
                // Display the view
                parent::display($tpl);
                
                // Set the document
                $this->setDocument();
        }
        
        /*
        * Method to set up the document properties
        *
        * @return void
        */
        protected function setDocument()
        {
            $document = JFactory::getDocument();
            $document->setTitle(JText::_('Phone Guide'));
        }
        
        private function makeTimeDropdown($start = 1, $end = 12)
        {
            for($i = $start; $i <= $end; $i++){
                $mtd.='<option value="'. ($i>12 ? $i-12 : $i) .'" '.( $i==6 ? 'Selected="selected"' : '' ).'>'.str_pad(($i>12 ? $i-12 : $i),2,"0",STR_PAD_LEFT).'</option>';
            }            
            return $mtd;
        }
        
        private function makeWeekEndingDropdown()
        {           
            $start = date("Y-m-d");            
            $saturdayotw = date("N", strtotime($start)); 
            for($i = 0; $i < 52; $i++){
                $mwed.='<option value="">'. date("Y - m - d ", strtotime("+". ( 6 - $saturdayotw ) . " days" , strtotime("-". (7*$i) . " days"))) .'</option>';
            }
            return $mwed;
        }
        
        private function makeWeekDaysDropdown()
        {           
            $start = date("Y-m-d");            
            $saturdayotw = date("N", strtotime($start)); 
            for($i = 0; $i < 6; $i++){
                $mwdd.='<option value="'.date("Y - m - d ", strtotime("+". ( 6 - $saturdayotw ) . " days" , strtotime("-". ($i) . " days"))).'" '.(($i%2) == 0 ? 'class="locked"' : '' ).'>'. date("Y - m - d ", strtotime("+". ( 6 - $saturdayotw ) . " days" , strtotime("-". ($i) . " days"))) .'</option>';
            }
            return $mwdd;
        }
        
        private function makeSpendTimeDropdown()
        {
            for($i = 0; $i <= 8; $i++){
                for($j = 0 ; $j < 4; $j ++){
                    if($i == 8 && $j > 0){
                        break;                        
                    }else{
                        $mtd.='<option value="'. $i.'.'.($j*25).'">'. $i.'.'.str_pad(($j*25),2,"0",STR_PAD_LEFT).'</option>';
                    }
                }
            }            
            return $mtd;
        }
}