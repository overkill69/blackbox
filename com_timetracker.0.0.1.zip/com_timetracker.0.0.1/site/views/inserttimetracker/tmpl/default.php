<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
JHtml::_('behavior.keepalive');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.tooltip');
 
?>
<h1> Insert Phone Guide </h1>
<!--pre>
<?php// var_dump($this->msg); ?>
</pre-->
<style>
    #inputForm{
        width: 80%;
        margin: 20px auto;
    }
    #basicInfo{
        display: block;
    }
    #detailInfo{
        display: none;
    }
    #inputFormRow{
        min-height: 25px;
    }
    .leftColumn{
        width: 40%;
        float: left;
        vertical-align: middle;
    }
    .rightColumn{
        width: 60%;
        float: left;
        vertical-align: middle;
    }
    .odd{
        background-color: #F3F3F3;
    }
    .locked{
        background-color: #CC3333;
    }
</style>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $('#weekday').change(function(e){
        $('#detailInfo').toggle('slow');            
   });
   
   $('[id^=endTime]').change(function(){       
        var start = $('#startTimeH').val() + ":" + $('#startTimeM').val() + " " + $('#startTimeT').val();
        var end = $('#endTimeH').val() + ":" + $('#endTimeM').val() + " " + $('#endTimeT').val();
        var diff = timeDiff(start, end);
        if( diff > 7 ){
            var calculateOT = diff - 7;
            $('#CTW').val(7);
            $('#COW').val(calculateOT);
            $('#RTW').val(7);
            $('#ROW').val(calculateOT);
        } else {
            $('#CTW').val(diff);
            $('#COW').val(0);
            $('#RTW').val(diff);
            $('#ROW').val(0);
        }
        //alert(diff);
   });
   $('[id*=TimeSpend]').change(function(){
       validateTimeSpend();
   });
   
   function timeDiff(start, end){       
       var startd = new Date($('#weekday').val() + " " + start);
       var endd = new Date($('#weekday').val() + " " + end);
       var diffms = endd - startd;
       var diffmnt = ((diffms/1000)/60)-30;
       var diffhours = (diffmnt/60);
       return diffhours;
   }
   
   function validateTimeSpend(){
       var xrt = $('#XRayTimeSpend').val();
       var ot = $('#OtherTimeSpend').val();
       var npt = $('#NonPTimeSpend').val();
       var tspend = parseFloat(xrt) + parseFloat(ot) +parseFloat(npt);
       if (tspend > 7 ){
           $('#ROW').val( $('#CTW').val() - tspend );                      
       }else{
           //alert("Regular time registered " + tspend );
           $('#RTW').val( $('#CTW').val() - tspend );           
       }
   }
});
</script>
<div>Tracking Form:</div>
 <form class="form-validate" action="<?php echo JRoute::_('index.php'); ?>" method="post" id="inserttimetracker" name="inserttimetracker">
     <input type="hidden" name="uid" value="<?php echo $this->msg[0]->id; ?>"/>
    <div id="inputForm">
        <div id="basicInfo">
            <div id="inputFormRow" class="leftColumn">Employee Last Name:</div><div id="inputFormRow" class="rightColumn"><?php echo $this->msg[0]->name; ?></div>
            <div id="inputFormRow" class="leftColumn odd">Employee First Name:</div><div id="inputFormRow" class="rightColumn odd"><?php echo $this->msg[0]->username; ?></div>
            <div id="inputFormRow" class="leftColumn">Team:</div><div id="inputFormRow" class="rightColumn"><select name="userteam"><option>Team Jhon Doe</option></select></div>
            <div id="inputFormRow" class="leftColumn odd">Week Ending:</div><div id="inputFormRow" class="rightColumn odd"><select name="weekending" id="weekdending"><?php echo $this->weekendings;?></select></div>
            <div id="inputFormRow" class="leftColumn">Day:</div><div id="inputFormRow" class="rightColumn"><select name="weekday" id="weekday"><?php echo $this->weekdays;?></select></div>    
            <div id="inputFormRow" class="leftColumn odd">Locked: </div><div id="inputFormRow" class="rightColumn odd"><input type="checkbox" name="locked" id="locked"/></div>
        </div>
        <div id="detailInfo">
            <div id="inputFormRow" class="leftColumn">Start Time:</div><div id="inputFormRow" class="rightColumn">
                <select name="startTimeH" id="startTimeH"><?php echo $this->hours; ?></select>
                <select name="startTimeM" id="startTimeM"><option value="00">00</option><option value="15">15</option><option value="30">30</option><option value="45">45</option></select>
                <select name="startTimeT" id="startTimeT"><option value="am">am</option><option value="pm">pm</option></select>
            </div>
            <div id="inputFormRow" class="leftColumn odd">Break #1:</div><div id="inputFormRow" class="rightColumn">
                <select name="break1H" id="break1H"><?php echo $this->hours; ?></select>
                <select name="break1M" id="break1M"><option value="00">00</option><option value="15">15</option><option value="30">30</option><option value="45">45</option></select>
                <select name="break1T" id="break1T"><option value="am">am</option><option value="pm">pm</option></select>
            </div>
            <div id="inputFormRow" class="leftColumn">Break #2:</div><div id="inputFormRow" class="rightColumn">
                <select name="break2H" id="break2H"><?php echo $this->hours; ?></select>
                <select name="break2M" id="break2M"><option value="00">00</option><option value="15">15</option><option value="30">30</option><option value="45">45</option></select>
                <select name="break2T" id="break2T"><option value="am">am</option><option value="pm">pm</option></select>
            </div>
            <div id="inputFormRow" class="leftColumn odd">End Time:</div><div id="inputFormRow" class="rightColumn">
                <select name="endTimeH" id="endTimeH"><?php echo $this->hours; ?></select>
                <select name="endTimeM" id="endTimeM"><option value="00">00</option><option value="15">15</option><option value="30">30</option><option value="45">45</option></select>
                <select name="endTimeT" id="endTimeT"><option value="am">am</option><option value="pm">pm</option></select>
            </div>
            <div id="inputFormRow" class="leftColumn">Calculated Time Worked: </div><div id="inputFormRow" class="rightColumn"><input type="text" name="CTW" id="CTW" value="0"/></div>
            <div id="inputFormRow" class="leftColumn odd">Calculated Overtime Worked:</div><div id="inputFormRow" class="rightColumn"><input type="text" name="COW" id="COW" value="0"/></div>
            <div id="inputFormRow" class="leftColumn">Regular (non-OT):</div><div id="inputFormRow" class="rightColumn"><input type="text" name="RTW" id="RTW" value="0"/></div>
            <div id="inputFormRow" class="leftColumn odd">Regular (OT):</div><div id="inputFormRow" class="rightColumn"><input type="text" name="ROW" id="ROW" value="0"/></div>        
            <div id="inputFormRow" class="leftColumn odd">X-Ray (non-OT):</div><div id="inputFormRow" class="rightColumn"><select name="XRayTime" id="XRayTimeSpend"><?php echo $this->spentHours; ?></select></div>
            <div id="inputFormRow" class="leftColumn">X-Ray (OT):</div><div id="inputFormRow" class="rightColumn"><select name="XRayOver" id="XRayOverSpend"><?php echo $this->spentHours; ?></select></div>
            <div id="inputFormRow" class="leftColumn odd">Other (non-OT):</div><div id="inputFormRow" class="rightColumn"><select name="OtherTime" id="OtherTimeSpend"><?php echo $this->spentHours; ?></select></div>
            <div id="inputFormRow" class="leftColumn odd">Other (OT):</div><div id="inputFormRow" class="rightColumn"><select name="OtherOver" id="OtherOverSpend"><?php echo $this->spentHours; ?></select></div>
            <div id="inputFormRow" class="leftColumn">Non Prod (non-OT):</div><div id="inputFormRow" class="rightColumn"><select name="NonPTime" id="NonPTimeSpend"><?php echo $this->spentHours; ?></select></div>
            <div id="inputFormRow" class="leftColumn odd">Non Prod (OT):</div><div id="inputFormRow" class="rightColumn"><select name="NonPOver" id="NonPOverSpend"><?php echo $this->spentHours; ?></select></div>
            <div id="inputFormRow" class="leftColumn">Comments (Non Prod - OT): </div><div id="inputFormRow" class="rightColumn"><textarea name="comments"></textarea></div>
            <div id="inputFormRow" class="leftColumn odd">Other Prod # Touched: </div><div id="inputFormRow" class="rightColumn"><input type="text" name="otherProdTouch" value="0"/></div>
            <div id="inputFormRow" class="leftColumn">Other Prod # Adj: </div><div id="inputFormRow" class="rightColumn"><input type="text" name="otherProdAdj" value="0"/></div>
            <div id="inputFormRow" class="leftColumn odd">General Comment (Non Prod - OT): </div><div id="inputFormRow" class="rightColumn"><textarea name="generalComments"></textarea></div>
            <div id="inputFormRow" class="leftColumn"><button type="submit" class="button"><?php echo JText::_('Submit'); ?></button><input type="button" value ="Reset"> </div><div id="inputFormRow" class="rightColumn"></div>
        </div>
    </div>
     <input type="hidden" name="option" value="com_timetracker" />
     <input type="hidden" name="task" value="inserttimetracker.submit" />
     <?php echo JHtml::_('form.token'); ?>
 </form>
