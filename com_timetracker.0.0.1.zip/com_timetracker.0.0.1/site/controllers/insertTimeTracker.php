<?php

defined( '_JEXEC' ) or die;

jimport('joomla.application.component.controller');
jimport('joomla.application.component.controllerform');


/**
 * Description of insertTimeTracker
 *
 * @author overkill
 */
class TimeTrackerControllerInsertTimeTracker extends JControllerForm
{
    public function getModel($name = '', $prefix = '', $config = array()) {
        if (empty($name)) {
                $name = $this->context;
        }

        return parent::getModel($name, $prefix, $config);
    }
    
    	public function submit()
        {
       // Check for request forgeries.
               JRequest::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

       // Initialise variables.
               $app = JFactory::getApplication();
               $model = $this->getModel('inserttimetracker');
       // Get the data from the form POST
               $data = JRequest::getVar('jform', array(), 'post', 'array');

               $form = $model->getForm();
               if (!$form) {
                   JError::raiseError(500, $model->getError());
                   return false;
               }
       // Now update the loaded data to the database via a function in the model
               $upditem = $model->updItem($_POST); /* @Andres: Updated to use $_POST because $data wass always empty */

       // check if ok and display appropriate message. This can also have a redirect if desired.
               if ($upditem) {
                   echo "<h2>Joining with us is successfully saved.</h2>";
               } else {
                   echo "<h2>Joining with us faild.</h2>";
               }

               return true;
           }
        
}

?>
