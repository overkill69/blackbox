<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// Include dependancy of the main model form
jimport('joomla.application.component.modelform');
// import Joomla modelitem library
jimport('joomla.application.component.modelitem');
// Include dependancy of the dispatcher
jimport('joomla.event.dispatcher');
 
/**
 * TimeTracker Model
 */
class TimeTrackerModelTimeTracker extends JModelItem
{
        /**
         * @var array messages       
         * @var object item
         */
        protected $messages;
        protected $item;
 
        /**
         * Get the data for a new qualification
         */
 /*       public function getForm($data = array(), $loadData = true)
        {
 
        $app = JFactory::getApplication('site');
 
        // Get the form.
                $form = $this->loadForm('com_timetracker.updtimetracker', 'updtimetracker', array('control' => 'jform', 'load_data' => true));
                if (empty($form)) {
                        return false;
                }
                return $form;
 
        }
 
        public function updItem($data)
        {
        // set the variables from the passed data
        $id = $data['id'];
        $greeting = $data['greeting'];
 
        // set the data into a query to update the record
                $db             = $this->getDbo();
                $query  = $db->getQuery(true);
        $query->clear();
                $query->update(' #__timetracker ');
                $query->set(' greeting = '.$db->Quote($greeting) );
                $query->where(' id = ' . (int) $id );
 
                $db->setQuery((string)$query);
 
        if (!$db->query()) {
            JError::raiseError(500, $db->getErrorMsg());
                return false;
        } else {
                return true;
                }
        }
 */
        /**
         * Returns a reference to the a Table object, always creating it.
         *
         * @param       type    The table type to instantiate
         * @param       string  A prefix for the table class name. Optional.
         * @param       array   Configuration array for model. Optional.
         * @return      JTable  A database object
         * @since       2.5
         */
        public function getTable($type = 'TimeTracker', $prefix = 'TimeTrackerTable', $config = array()) 
        {
                return JTable::getInstance($type, $prefix, $config);
        }
        /**
         * Get the message
         * @param  int    The corresponding id of the message to be retrieved
         * @return string The message to be displayed to the user
         */
        public function getMsg($id = 1) 
        {
                if (!is_array($this->messages))
                {
                        $this->messages = array();
                }
 
                if (!isset($this->messages[$id])) 
                {
                        //request the selected id
                        $jinput = JFactory::getApplication()->input;
                        $id = $jinput->get('id', 1, 'INT' );
 
                        // Get a TableHelloWorld instance
                        $table = $this->getTable();
 
                        // Load the message
                        $table->load($id);
 
                        // Assign the message
                        $this->messages[$id] = $table->teamid;
                }
 
                return $this->messages[$id];
        }
        
        public function getProfile( $user_id = 611)
        {
            if(!isset($user_id)){
                return "Must log to see your phone guide";
            } else {
                $db = JFactory::getDbo();
                $query = $db->getQuery(true);
                $query->select('*');
                $query->from($db->nameQuote('#__users'));
                //$query->join('LEFT', $db->nameQuote('#__mycustomuserinfo') . ' AS uc ON uc.id = u.id');
                $query->where(' id = ' . (int) $user_id);
                $db->setQuery((string)$query);
                $profile = $db->loadObjectList();
                return $profile;              
            }
        }
        
        public function saveTimeTracking(array $params)
        {
            if(!is_array($params)){
                return "Error!!! Params are empty";
            }
            // Get a db connection.
            $db = JFactory::getDbo();
            // Create a new query object.
            $query = $db->getQuery(true);
            // Insert columns.
            $columns = array('user_id', 'profile_key', 'profile_value', 'ordering');
            // Insert values.
            $values = array(1001, $db->quote('custom.message'), $db->quote('Inserting a record using insert()'), 1);
            // Prepare the insert query.
            $query
                ->insert($db->quoteName('#__user_profiles'))
                ->columns($db->quoteName($columns))
                ->values(implode(',', $values));
            // Reset the query using our newly populated query object.
            $db->setQuery($query);
        }
        
        public function getItem() 
        {
                if (!isset($this->item)) 
                {
                        $id = $this->getState('message.id');
                        $this->_db->setQuery($this->_db->getQuery(true)
                                ->from('#__timetracker as h')
                                ->leftJoin('#__categories as c ON h.catid=c.id')
                                ->select('h.greeting, h.params, c.title as category')
                                ->where('h.id=' . (int)$id));
                        if (!$this->item = $this->_db->loadObject()) 
                        {
                                $this->setError($this->_db->getError());
                        }
                        else
                        {
                                // Load the JSON string
                                $params = new JRegistry;
                                // loadJSON is @deprecated    12.1  Use loadString passing JSON as the format instead.
                                //$params->loadString($this->item->params, 'JSON');
                                $params->loadJSON($this->item->params);
                                $this->item->params = $params;
 
                                // Merge global params with item params
                                $params = clone $this->getState('params');
                                $params->merge($this->item->params);
                                $this->item->params = $params;
                        }
                }
                return $this->item;
        }
        
        public function getForm($data = array(), $loadData = true)
    {
        $app = JFactory::getApplication('site');

// Get the form.
        $form = $this->loadForm('com_timetracker.inserttimetracker', 'inserttimetracker', array('control' => 'jform', 'load_data' => true), true);

        if (empty($form)) {
            return false;
        }
        return $form;
    }

//Nwely added method for saving data
    public function updItem($data) {
// set the variables from the passed data
        $uid = $data['uid'];  
        $userteam = $data['userteam'];
        $weekending = $data['weekending'];
        $weekday = $data['weekday'];
        $StartTime = $data['startTimeH'] . ":" . $data['startTimeM']." ". $data['startTimeT'];
        $Break1 = $data['break1H'] . ":" . $data['break1M']." ". $data['break1T'];
        $Break2 = $data['break2H'] . ":" . $data['break2M']." ". $data['break2T'];
        $EndTime = $data['endTimeH'] . ":" . $data['endTimeM']." ". $data['endTimeT'];
        $CTW = $data['CTW'];
        $COW = $data['COW'];
        $RTW = $data['RTW'];
        $ROW = $data['ROW'];
        $XRayTime = $data['XRayTime'];
        $XRayOver = $data['XRayOver'];
        $OtherTime = $data['OtherTime'];
        $OtherOver = $data['OtherOver'];
        $NonPTime = $data['NonPTime'];
        $NonPOver = $data['NonPOver'];
        $comments = $data['comments'];
        $otherProdTouch = $data['otherProdTouch'];
        $otherProdAdj = $data['otherProdAdj'];
        $generalComments = $data['generalComments'];
        
/*        $fname = $data['fname'];
        $lname = $data['lname'];
        $age = $data['age'];
        $city = $data['city'];
        $telephone = $data['telephone'];
        $email = $data['email'];
        $comments = $data['comments'];*/
// set the data into a query to update the record
        $db = $this->getDbo();
        $query = $db->getQuery(true);
        $query->clear();

        $db = & JFactory::getDBO();
        $query = "INSERT INTO #___timetracker` (`tt_id`, `id`, `tt_teamid`, `tt_weekending`, `tt_weekday`, `tt_locked`, `tt_starttime`, `tt_break1`, `tt_break2`, `tt_endtime`, `tt_timeworked`, `tt_overtimeworked`, `tt_regulartime`, `tt_regularovertime`, `tt_xraytime`, `tt_xrayovertime`, `tt_othertime`, `tt_otherovertime`, `tt_nonprodtime`, `tt_nonprodovertime`, `tt_commentsnonprod`, `tt_otherprodtouched`, `tt_otherprodadj`, `tt_generalcomments`)
                    VALUES (NULL,'" . $uid . "','" . $userteam . "','" . $weekending . "','" . $weekday . "','" . $StartTime . "','" . $Break1 . "','" . $Break2 . "','" . $EndTime . "','" . $CTW . "','" . $COW . "','" . $RTW . "','" . $ROW . "','" . $XRayTime . "','" . $XRayOver . "','" . $OtherTime . "','" . $OtherOver . "','" . $NonPTime . "','" . $NonPOver . "','" . $comments . "','" . $otherProdTouch . "','" . $otherProdAdj . "','" . $generalComments . "')";
        die($query);
        $db->setQuery((string) $query);

        if (!$db->query()) {
            JError::raiseError(500, $db->getErrorMsg());
            return false;
        } else {
            return true;
        }
    }

}