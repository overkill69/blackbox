DROP TABLE IF EXISTS `#__timetracker`;
 
CREATE TABLE IF NOT EXISTS `#__timetracker` (
  `tt_id` INT NOT NULL AUTO_INCREMENT,
  `id` INT NOT NULL,
  `tt_teamid` INT NOT NULL,
  `tt_weekending` DATE NOT NULL,
  `tt_weekday` DATE NOT NULL,
  `tt_locked` TINYINT(1) NOT NULL,
  `tt_starttime` TIME NOT NULL,
  `tt_break1` TIME NOT NULL,
  `tt_break2` TIME NOT NULL,
  `tt_endtime` TIME NOT NULL,
  `tt_timeworked` DECIMAL(3,2) NOT NULL,
  `tt_overtimeworked` DECIMAL(3,2) NOT NULL,
  `tt_regulartime` DECIMAL(3,2) NOT NULL,
  `tt_regularovertime` DECIMAL(3,2) NOT NULL,
  `tt_xraytime` DECIMAL(3,2) NOT NULL,
  `tt_xrayovertime` DECIMAL(3,2) NOT NULL,
  `tt_othertime` DECIMAL(3,2) NOT NULL,
  `tt_otherovertime` DECIMAL(3,2) NOT NULL,
  `tt_nonprodtime` DECIMAL(3,2) NOT NULL,
  `tt_nonprodovertime` DECIMAL(3,2) NOT NULL,
  `tt_commentsnonprod` VARCHAR(250) NULL,
  `tt_otherprodtouched` INT NOT NULL,
  `tt_otherprodadj` INT NOT NULL,
  `tt_generalcomments` VARCHAR(250) NULL,
  PRIMARY KEY (`tt_id`))
ENGINE = MyISAM;